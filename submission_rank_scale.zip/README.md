# CSI 300 指数增强挑战赛 — 提交包（v3 · 84 因子）

**方案：84 因子 + LightGBM 多种子集成（40 个模型）**

---

## 一、快速开始

```python
from inference import InferenceModel

model = InferenceModel(model_dir="./model/")        # 平台只调用一次

df = model.predict(as_of_date="2022-01-04",
                   data={"MarketData":      market_df,
                         "Factor33_winsor":  factor_df,
                         "Barra_factor":     barra_df})   # 每个信号日调用一次
```

输出（恰好三列）：

```
      date    code   score
2022-01-04  SH000001  0.4213
```

- `date`：Python `str`（object dtype），恒等于入参 `as_of_date`
- `code`：object dtype，覆盖当日合法股票池每一只，无重复、无多余
- `score`：float64 有限实数，**数值越大表示越看好**

### 打包自检

```bash
python selfcheck.py     # 不需要原始数据
```

预期：`max|Δ| = 0.000e+00` / `PASS ✅ 模型文件完整、可复现`

---

## 二、目录结构

```
submission/
├── inference.py         # 推理入口：InferenceModel 类
├── features.py          # 70 个因子的计算（训练与推理【共用同一份代码】）
├── train.py             # 复现训练脚本（import 同一个 features.py）
├── selfcheck.py         # 打包自检
├── requirements.txt     # 依赖（已锁定版本）
├── README.md            # 本说明
└── model/
    ├── meta.json                            # 冻结全部配置
    ├── model_g{1..4}_s{...}.txt             # 40 个 LightGBM booster
    ├── _check_features.parquet              # 自检样本（343 行 × 70 特征）
    └── _check_expected.parquet              # 自检期望分数
```

---

## 三、方法

### 3.1 股票池

当日 `Barra_factor` 中的 `代码` 集合。**已核实与 `HS300_weight` 的当日成分完全一致**
（1703 个交易日、每日恰好 300 只、零差异）。

### 3.2 特征（84 个）

| 类别 | 个数 | 说明 |
|---|---|---|
| **量价 / 基本面（自算）** | 16 | `rev_5` `bias_20` `vol_cv_20` `intraday_rev_1` `macd_hist` `pv_corr_20` `turn_20` `atr_14_norm` `ep_ttm` `size` `btop` `beta` `illiq_20` `downside_vol_20` `overnight_rev` `sharpe_100` |
| **自研低相关因子** | 12 | `pv_elastic_20` `close_vs_mid_20` `turn_accel` `shadow_up_20` `overnight_vol_share_20` `trend_eff_20` `kurt_20` `rng_to_absret_20` `elastic_asym_20` `close_vs_vwap_20` `intraday_autocorr_20` `var_ratio_5_20` |
| **Barra 风格暴露** | 10 | `市值` `贝塔` `动量` `残差波动` `非线性市值` `账面市值比` `流动性` `盈利` `成长` `杠杆` |
| **Factor33_winsor 全量字段** | 32 | `Q_*` 前缀，含质量类基本面 `Q_roe_avg_ttm` `Q_roa_avg_ttm` `Q_gross_profit_rate_ttm` `Q_net_profit_rate_ttm` `Q_debt_to_asset_lf` `Q_current_ratio_lf` `Q_ps_ttm` |
| **行业内相对强弱** | **14** | `IN_*` 前缀。**本版新增**：当日全截面 z-score 再减去【当日同行业】均值 → 个股相对所属行业的位置（此前完全缺失的维度） |

**版本演进**

| 版本 | 特征数 | RankIC（2019-2022 均值） |
|---|---|---|
| v1 | 38 | 0.0472 |
| v2 | 70 | 0.0514 |
| **v3（本版）** | **84** | **0.0518** |

处理：当日横截面 z-score（clip ±50）→ NaN 填 0（z-score 下 0 即截面均值）。

### 3.2.1 行业映射说明（重要）

`IN_*` 因子需要行业代码，而平台入参只有三张表。处理方式：

1. 优先使用入参 `data` 中的 `"HS300_industry"`（若平台提供）；
2. 否则读取包内 `model/industry_map.parquet`（**由公开数据 `HS300_industry` 派生，510,900 行 / 31 个行业 / 113 KB**），
   并用 `model/industry_fallback.json` 对查不到的日期做兜底；
3. 两者都不可用时，`IN_*` 为 NaN → 填 0，**与训练时行业缺失的处理完全一致**。

> 该映射表只含「日期 + 代码 + 行业代码（整数编码）」，不含任何价格或收益信息。

### 3.3 标签

比赛口径 `y = Open(t+2)/Open(t+1) − 1`（逐股票 shift；`|y| > 0.5` 置 NaN），
再取**当日横截面十分位排名（0–9）**作为回归目标。

### 3.4 模型与集成

- LightGBM，**4 组超参 × 10 个固定种子 = 40 个模型**

| 组 | num_leaves | max_depth | learning_rate | n_estimators | min_child_samples | subsample | colsample | reg_lambda |
|---|---|---|---|---|---|---|---|---|
| g1 | 15 | 4 | 0.04 | 400 | 200 | 0.8 | 0.8 | 2.0 |
| g2 | 31 | 5 | 0.03 | 500 | 150 | 0.8 | 0.7 | 5.0 |
| g3 | 7 | 3 | 0.05 | 350 | 300 | 0.9 | 0.9 | 1.0 |
| g4 | 63 | 6 | 0.02 | 600 | 100 | 0.7 | 0.6 | 10.0 |

- 最终分数 = 40 个模型**当日横截面百分位排名**的等权平均
- `score_power = 1.0`：**不做任何分数形态变换**

训练数据：2016-01-04 ~ 2022-12-30，**575,954 行 / 1,701 个交易日**。

---

## 四、性能（4 个真样本外年份）

每年**只用该年之前**的数据训练，逐年评估：

| 年度 | 天数 | **RankIC** | ICIR | IC 日胜率 |
|---|---|---|---|---|
| 2019 | 244 | 0.0528 | 0.4355 | 65.2% |
| 2020 | 243 | **0.0582** | 0.4481 | 65.8% |
| 2021 | 243 | 0.0435 | 0.2753 | 61.3% |
| 2022 | 240 | 0.0526 | 0.3975 | 65.0% |
| **均值** | **970** | **0.0518** | **0.3891** | **64.3%** |

RankIC 最差年份 0.0435，无塌陷年。

### 版本对比

| 版本 | 特征数 | RankIC（4 年均值） | ICIR 均值 | 最差年份 |
|---|---|---|---|---|
| v1 | 38 | 0.0472 | 0.3454 | 0.0453 |
| v2 | 70 | 0.0514 | 0.3624 | 0.0446 |
| **v3** | **84** | **0.0518** | **0.3891** | 0.0435 |

---

## 五、一致性核验（全部通过）

| 核验项 | 结果 |
|---|---|
| **推理分数 vs 训练口径分数**（3 个日期） | **max\|Δ\| = 0.000e+00** ✅ |
| 输出契约（三列 / dtype / 无重复 / 全有限 / date 一致 / 覆盖全池） | 全部 PASS ✅ |
| **120 日滚动窗口 vs 全历史** | Spearman **1.000000**，max\|Δ\| = 5.8e-04 ✅ |
| 12 个自研因子 vs 旧面板 | 12/12 秩相关 > 0.99 ✅ |
| `Q_*` 字段 vs Factor33 原表 | **32/32 逐一一致** ✅ |
| 最大回看 | **100 个交易日**（约束 ≤120）✅ |
| 常量列 | 无 ✅ |
| 训练 / 推理的行业代码处理 | 同一份 `industry_map.parquet` + 同一兜底逻辑 ✅ |

### 窗口敏感性说明

平台只传 ≤120 日历史。已核实 **120 日窗口下 70 个因子全部收敛**。
为保证这一点，`sharpe` 因子的回看从 120 日**收紧到 100 日**
（120 日窗口下 120 日 sharpe 会完全缺失，导致分数明显漂移）。

---

## 六、合规性

- ✅ 只读取 `model_dir` 与入参 `data`，**不读写其它文件、不联网**
- ✅ 推理期**不做任何拟合**；全部参数冻结在 `model/*.txt` 与 `model/meta.json`
- ✅ 无 `sys.exit` / `subprocess` / `os.system` / `eval` / `exec` / `__import__`
- ✅ 跨调用无共享状态
- ✅ 未使用 2016–2022 公开数据之外的任何数据源
- ✅ 依赖仅 numpy / pandas / lightgbm（`features.py` 随包提供）
- ✅ 所有因子严格 Point-in-Time（只用 `shift(正数)` 与向后 `rolling`）

---

## 七、复现训练

```bash
python train.py --data_dir <公开数据目录> --out_dir ./model
```

`train.py` 与推理共用同一份 `features.py`，4 组 × 10 种子 = 40 个模型，同数据同环境可复现。
